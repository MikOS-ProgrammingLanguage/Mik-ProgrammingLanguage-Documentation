int return_test_lib_f2() {
    return 1;
}