int return_test_lib_f1() {
    return 1;
}