int test_glob_val = 100;

int test_the_fucking() {
    return 1;
}