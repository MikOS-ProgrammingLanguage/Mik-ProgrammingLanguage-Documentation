package compiler_util

func GenerateAsm() bool {
	return true
}
